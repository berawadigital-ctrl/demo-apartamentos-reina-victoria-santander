# Licencias de los activos

| Activo | Origen | Autor | Licencia |
|---|---|---|---|
| img/hero.webp (+ hero-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `waves`, semilla 9801) | Berawa Solutions | Propia (generada por script) |
| img/intro.webp (+ intro-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `arches`, semilla 9802) | Berawa Solutions | Propia (generada por script) |
| img/r1.webp (+ r1-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `waves`, semilla 9811) | Berawa Solutions | Propia (generada por script) |
| img/r2.webp (+ r2-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `arches`, semilla 9812) | Berawa Solutions | Propia (generada por script) |
| img/r3.webp (+ r3-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `columns`, semilla 9813) | Berawa Solutions | Propia (generada por script) |
| img/g1.webp (+ g1-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `hills`, semilla 9821) | Berawa Solutions | Propia (generada por script) |
| img/g2.webp (+ g2-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `waves`, semilla 9822) | Berawa Solutions | Propia (generada por script) |
| img/g3.webp (+ g3-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `skyline`, semilla 9823) | Berawa Solutions | Propia (generada por script) |
| img/g4.webp (+ g4-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `arches`, semilla 9824) | Berawa Solutions | Propia (generada por script) |
| img/g5.webp (+ g5-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `columns`, semilla 9825) | Berawa Solutions | Propia (generada por script) |
| img/g6.webp (+ g6-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `skyline`, semilla 9826) | Berawa Solutions | Propia (generada por script) |
| fonts/cormorant.woff2 | https://github.com/CatharsisFonts/Cormorant | Christian Thalmann (Catharsis Fonts) | SIL OFL 1.1 |

Ninguna imagen es una foto ni muestra el establecimiento: son ilustraciones propias y se rotulan «Imagen ilustrativa». Detalle por fichero (hash, parámetros de generación) en `berawa/asset_manifest.json` y `berawa/evidence/assets/`.

Los textos proceden de la web pública del negocio (apartamentosreinavictoria.com, leída el 29/10/2026; ver `berawa/sources.json`); no se han copiado sus fotos, logotipos, vídeos ni testimonios.
